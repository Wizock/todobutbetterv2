# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['todobutbetterv2']
install_requires = \
['Flask-Admin>=1.6.0,<2.0.0', 'Flask-Mail>=0.9.1,<0.10.0']

setup_kwargs = {
    'name': 'todobutbetterv2',
    'version': '0.2.1',
    'description': 'A better developed TODO-list application for actual useage, a modern day trello for lightweight todo with shareability and modern accents.',
    'long_description': None,
    'author': 'Rohaan Ahmed',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
